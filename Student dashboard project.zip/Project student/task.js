const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');

// Add task when button is clicked
addTaskBtn.addEventListener('click', function (event) {
    event.preventDefault(); // Stop form from submitting
    addTask();
});

// Add task when Enter key is pressed
taskInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault(); // Stop form from submitting
        addTask();
    }
});

function addTask() {
    const taskText = taskInput.value.trim();

    if (!taskText) {
        alert('Please enter a task!');
        return;
    }

    // Create a new list item
    const li = document.createElement('li');

    const span = document.createElement('span');
    span.textContent = taskText;

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.classList.add('delete-btn');

    // Append span and button to li
    li.appendChild(span);
    li.appendChild(deleteBtn);

    // Append li to the task list
    taskList.appendChild(li);

    // Clear the input
    taskInput.value = '';

    // Delete button functionality
    deleteBtn.addEventListener('click', () => {
        taskList.removeChild(li);
    });

    // Mark as completed
    span.addEventListener('click', () => {
        li.classList.toggle('completed');
    });
}