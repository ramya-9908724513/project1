document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  if (!loginForm) return;
  const errorMessage = document.getElementById('errorMessage');

  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const email = (document.getElementById('email')?.value || '');
    const password = (document.getElementById('password')?.value || '');

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find(user => user.email === email && user.password === password);

    if (foundUser) {
      localStorage.setItem('loggedInUser', JSON.stringify(foundUser));
      if (errorMessage) errorMessage.textContent = '';
      alert('Login successful!');
      window.location.href = 'home.html';
    } else {
      if (errorMessage) errorMessage.textContent = 'Invalid email or password.';
      alert('Invalid email or password.');
    }
  });
});