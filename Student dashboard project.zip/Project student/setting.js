$(function () {
  $("input").checkboxradio({
    icon: false,
  });
  $("fieldset").controlgroup();
});
const $changeBtn = $("#changePwdBtn");
const $name = $("#name");
const $email = $("#email");
const $submit = $("#submit");
const $oldPwd = $("#oldPwd"),
  $newPwd = $("#newPwd"),
  $confirmPwd = $("#confirmPwd");

$changeBtn.on("click", function () {
  const oldVal = ($oldPwd.val() || "").trim();
  const newVal = ($newPwd.val() || "").trim();
  const confVal = ($confirmPwd.val() || "").trim();

  if (!oldVal || !newVal || !confVal) {
    alert("Please fill all password fields.");
    return;
  }
  if (newVal !== confVal) {
    alert("New password and confirm password do not match.");
    return;
  }

  let user = null;
  try {
    user = JSON.parse(localStorage.getItem("loggedInUser") || "null");
  } catch (e) {
    user = null;
  }
  if (!user || !user.password) {
    alert("No logged-in user found. Please log in first.");
    return;
  }
  if (user.password !== oldVal) {
    alert("Old password is incorrect.");
    return;
  }

  user.password = newVal;
  try {
    localStorage.setItem("loggedInUser", JSON.stringify(user));
  } catch (e) {}
  // also update in users[] if present
  try {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const i = users.findIndex((u) => u.email === user.email);
    if (i > -1) {
      users[i].password = newVal;
      localStorage.setItem("users", JSON.stringify(users));
    }
  } catch (e) {
    /* ignore */
  }

  // notify other tabs
  try {
    localStorage.setItem("profileUpdateTS", String(Date.now()));
  } catch (e) {}
  alert("Password changed successfully.");
  $oldPwd.val("");
  $newPwd.val("");
  $confirmPwd.val("");
});
// edit profile info 
$submit.on("click", function () {
  const name = ($name.val() || "").trim();
  const email = ($email.val() || "").trim();

  if (!name || !email) {
    alert("Name and email cannot be empty.");
    return;
  }
  let user = null;
  try {
    user = JSON.parse(localStorage.getItem("loggedInUser") || "null");
  } catch (e) {
    user = null;
  }
  user.password = newVal;
  try {
    localStorage.setItem("loggedInUser", JSON.stringify(user));
  } catch (e) {}
  try {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const i = users.findIndex((u) => u.email === user.email);
    if (i > -1) {
      users[i].password = newVal;
      localStorage.setItem("users", JSON.stringify(users));
    }
  } catch (e) {
  }    /* ignore */
  user.name = name;
  user.email = email;
  try {
    localStorage.setItem("loggedInUser", JSON.stringify(user));
  } catch (e) {}
  // also update in users[] if present

  // notify other tabs
  
  try {
    localStorage.setItem("profileUpdateTS", String(Date.now()));
  } catch (e) {}
  alert("Profile updated successfully.");
  $name.val("");
  $email.val("");
});