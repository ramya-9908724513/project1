document.getElementById('signupForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  const number = document.getElementById('number').value.trim();
  if (!name || !email || !password || !number) {
    alert("Please fill all the fields!");
    return; 
  }
  let users = JSON.parse(localStorage.getItem("users")) || [];
  const userExists = users.some(user => user.email === email);
  if (userExists) {
    alert("An account with this email already exists!");
    return;
  }

  // Add new user
  users.push({ name, email, password, number });
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("signupData", JSON.stringify({ name, email, password, number }));
  this.reset();
alert("Signup successful! Please log in.");
  // Redirect to login page
  window.location.href = "login.html";
});
