function updateClock() {
      const now = new Date();
      const time = now.toLocaleTimeString();
      document.getElementById('clock').textContent = time;
    }
setInterval(updateClock, 1000);
document.addEventListener('DOMContentLoaded', function() {
  const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
  if (loggedInUser && loggedInUser.name) {
    document.getElementById('username').value = "Hi " + loggedInUser.name + " !";
  }
});
document.addEventListener('DOMContentLoaded', function() {
  const noteInput = document.getElementById('noteInput');
  const addBtn = document.getElementById('addNoteBtn');
  const noteList = document.getElementById('noteList');
  let notes = [];

  function renderNotes() {
    noteList.innerHTML = '';
    notes.forEach((note) => {
      const li = document.createElement('li');
      li.textContent = note;
      noteList.appendChild(li);
    });
  }

  function addNote() {
    const value = noteInput.value.trim();
    if (!value) return;
    notes.push(value);
    renderNotes();
    noteInput.value = '';
  }
  addBtn.addEventListener('click', addNote);
  noteInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') addNote(); });
  renderNotes();
});
