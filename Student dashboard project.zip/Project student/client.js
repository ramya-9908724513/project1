$(document).ready(() => {
  $.get("https://jsonplaceholder.typicode.com/users", (users) => {
    const clickHere =
      "background-color: white; border: 2px solid hwb(201 0% 0%); border-radius: 18px; color: black; font-weight: 600; font-size: 12px; padding: 4px 10px 4px 10px;";
    users.forEach((user) => {
      console.log(user);
      $("#td1").append(`<td id=${user.id}> ${user.name} </td>`).val();
      $("#td2").append(`<td id=${user.id}> ${user.email} </td>`).val();
      $("#td3").append(`<td id=${user.id}> ${user.phone} </td>`).val();
      $("#td4").append(
        `<th><button class="buttonHover" style= "${clickHere}" id="${user.id}" onclick="fun(${user.id}) "> click-here </button></td>`
      );
      $(".buttonHover").hover(
        function () {
          $(this)
            .css("background-color", "hwb(201 0% 0%)")
            .css("border", "2px solid hwb(201 0% 0%)")
            .css("color", "white");
        },
        function () {
          $(this).css("background-color", "white").css("color", "black");
        }
      );
    });
  });
});
$("#bk-btn").click(() => {
  $("#content1").hide();
  $("bk-btn").hide();
  $(".tables").show();
});
function fun(usrid) {
  $(".tables").hide();
  console.log("fun id ==> " + usrid);
  $.get("https://jsonplaceholder.typicode.com/users/" + usrid, (user) => {
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">Name </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.name} </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">User-Name </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.username} </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">Email </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.email} </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">Phone-no </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.name} </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">Address </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.address.street}, ${user.address.suite}, </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">City </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.address.city} </td></tr>`
    );
    $("#rt").append(
      `<tr class="heading1" style="font-size: 21px; font-weight: 600;"><td style="text-align: right; margin-right: 31px;">Zip-Code </td> <td> : </td> <td style="text-align: left; margin-left: 36px;"> ${user.address.zipcode} </td></tr>`
    );
  });
  $("#content1").slideDown();
  $("#bk-btn").show();
  $("#rt").empty();
}
